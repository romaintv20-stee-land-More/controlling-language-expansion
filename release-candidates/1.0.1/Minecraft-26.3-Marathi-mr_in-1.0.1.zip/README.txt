Minecraft 26.3 Marathi language pack (mr_in)
Place this ZIP in .minecraft/resourcepacks, enable it in Minecraft, then select Marathi in Language settings.
Install Controlling Language Expansion 1.0.1 separately for Controlling's 12 Marathi strings.
Translations reuse Beyond & More 26.1.2 wherever the English key/meaning is unchanged. New or modified lines use machine-assisted Marathi and need native-speaker review.
